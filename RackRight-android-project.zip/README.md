# Ivy Warehouse Design Tool

Android app for concept-stage warehouse design: size and cost racking, conveyors, AS/RS, AutoStore, ACRs, AMRs and sortation, manual vs automated, with layouts, recommendations and regional cost benchmarks.

The app is a native Android shell (`app/src/main/java/.../MainActivity.java`) hosting the web app in `app/src/main/assets/index.html`, served offline from `https://appassets.androidplatform.net`.

## Builds
Every push runs **Actions → Build Android** and publishes a pre-release under **Releases**:
- `RackRight-test.apk` – installable test build (package `com.sleigh.rackright.test`)
- `RackRight-PLAYSTORE.aab` – signed Play Store bundle, only when the secrets `UPLOAD_KEYSTORE_BASE64` and `UPLOAD_KEYSTORE_PASSWORD` are set (key alias `upload`).

## Updating the app
Replace `app/src/main/assets/index.html` with the latest web version and commit; the version number follows the build number.
